"use client";

import { useState, useEffect } from "react";
import {
  Menu,
  Bell,
  User,
  Search,
  ChevronDown,
  LogOut,
  LayoutDashboard,
  AlertTriangle,
  GitBranch,
  CheckSquare,
  FileText,
  Settings,
  Info,
} from "lucide-react";
import useUser from "@/utils/useUser";

export default function VSMPage() {
  const { data: user, loading: userLoading } = useUser();
  const [selectedLine, setSelectedLine] = useState(null);
  const [lines, setLines] = useState([]);

  useEffect(() => {
    if (!userLoading && !user) {
      if (typeof window !== "undefined") {
        window.location.href = "/account/signin";
      }
    }
  }, [user, userLoading]);

  useEffect(() => {
    const fetchLines = async () => {
      try {
        const response = await fetch("/api/production-lines");
        if (response.ok) {
          const data = await response.json();
          setLines(data.lines || []);
          if (data.lines && data.lines.length > 0) {
            setSelectedLine(data.lines[0].id);
          }
        }
      } catch (error) {
        console.error("Error fetching lines:", error);
      }
    };
    fetchLines();
  }, []);

  if (userLoading || !user) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-[#F8FAFC]">
        <div className="text-slate-600">Chargement...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F8FAFC] font-inter">
      <header className="fixed top-0 left-0 right-0 z-10 flex items-center justify-between px-4 md:px-6 h-16 bg-white shadow-sm">
        <div className="hidden md:flex items-center">
          <span className="text-[20px] font-medium text-slate-700">
            ProcessFlow Smart
          </span>
        </div>

        <div className="flex-1 mx-4 max-w-lg">
          <div className="flex items-center bg-gray-100 rounded-full px-4 py-2">
            <Search className="w-4 h-4 text-slate-400" />
            <select
              value={selectedLine || ""}
              onChange={(e) => setSelectedLine(parseInt(e.target.value))}
              className="flex-1 bg-transparent text-sm pl-2 outline-none cursor-pointer"
            >
              <option value="">Sélectionner une ligne</option>
              {lines.map((line) => (
                <option key={line.id} value={line.id}>
                  {line.name}
                </option>
              ))}
            </select>
            <ChevronDown className="w-4 h-4 text-slate-400" />
          </div>
        </div>

        <div className="flex items-center space-x-4">
          <div className="hidden sm:flex items-center text-sm font-medium text-slate-600">
            <User className="w-5 h-5 mr-2 text-slate-400" />
            {user.name || user.email}
          </div>
          <button className="relative p-2 rounded-full hover:bg-gray-100">
            <Bell className="w-5 h-5 text-slate-400" />
          </button>
        </div>
      </header>

      <aside className="hidden md:flex fixed top-16 left-0 flex-col items-center w-16 py-6 space-y-4 h-[calc(100vh-4rem)] bg-white border-r border-gray-100">
        <a
          href="/"
          className="p-3 rounded-full bg-white shadow ring-1 ring-gray-100 text-slate-400 hover:text-violet-500"
        >
          <LayoutDashboard className="w-5 h-5" />
        </a>
        <a
          href="/amdec"
          className="p-3 rounded-full bg-white shadow ring-1 ring-gray-100 text-slate-400 hover:text-violet-500"
        >
          <AlertTriangle className="w-5 h-5" />
        </a>
        <a
          href="/actions"
          className="p-3 rounded-full bg-white shadow ring-1 ring-gray-100 text-slate-400 hover:text-violet-500"
        >
          <CheckSquare className="w-5 h-5" />
        </a>
        <a
          href="/reporting"
          className="p-3 rounded-full bg-white shadow ring-1 ring-gray-100 text-slate-400 hover:text-violet-500"
        >
          <FileText className="w-5 h-5" />
        </a>
        <button className="p-3 rounded-full shadow ring-1 ring-gray-100 bg-violet-500 text-white">
          <GitBranch className="w-5 h-5" />
        </button>
        <div className="flex-1"></div>
        <a
          href="/settings"
          className="p-3 rounded-full bg-white shadow ring-1 ring-gray-100 text-slate-400 hover:text-violet-500"
        >
          <Settings className="w-5 h-5" />
        </a>
        <a
          href="/account/logout"
          className="p-3 rounded-full bg-white shadow ring-1 ring-gray-100 text-slate-400 hover:text-violet-500"
        >
          <LogOut className="w-5 h-5" />
        </a>
      </aside>

      <main className="pt-16 md:pl-16">
        <div className="p-6">
          <div className="mb-6">
            <h2 className="text-2xl font-medium text-slate-700">
              Value Stream Mapping
            </h2>
            <p className="text-sm text-slate-500 mt-1">
              Optimisation des flux et détection des goulots
            </p>
          </div>

          <div className="bg-white rounded-[14px] p-12 shadow-sm border border-gray-100">
            <div className="flex flex-col items-center justify-center py-20">
              <div className="w-20 h-20 bg-violet-100 rounded-full flex items-center justify-center mb-6">
                <GitBranch className="w-10 h-10 text-violet-500" />
              </div>
              <h3 className="text-xl font-medium text-slate-700 mb-2">
                Module VSM à venir
              </h3>
              <p className="text-slate-500 text-center max-w-md mb-8">
                Le module Value Stream Mapping permettra de visualiser vos flux
                de production, identifier les goulots d'étranglement et simuler
                des améliorations en temps réel.
              </p>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 w-full max-w-3xl">
                <div className="p-6 bg-gray-50 rounded-lg">
                  <div className="text-violet-500 font-semibold mb-2">
                    Cartographie
                  </div>
                  <p className="text-sm text-slate-600">
                    Visualisation complète de vos processus avec temps VA/NVA
                  </p>
                </div>

                <div className="p-6 bg-gray-50 rounded-lg">
                  <div className="text-violet-500 font-semibold mb-2">
                    Analyse
                  </div>
                  <p className="text-sm text-slate-600">
                    Détection automatique des goulots et calcul du Lead Time
                  </p>
                </div>

                <div className="p-6 bg-gray-50 rounded-lg">
                  <div className="text-violet-500 font-semibold mb-2">
                    Simulation
                  </div>
                  <p className="text-sm text-slate-600">
                    Tests "What-If" pour optimiser vos flux de production
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>

      <style jsx global>{`
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap');
        .font-inter { font-family: 'Inter', sans-serif; }
      `}</style>
    </div>
  );
}
