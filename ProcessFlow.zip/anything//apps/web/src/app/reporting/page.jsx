"use client";

import { useState, useEffect } from "react";
import {
  Menu,
  X,
  Bell,
  User,
  Search,
  ChevronDown,
  LogOut,
  LayoutDashboard,
  AlertTriangle,
  GitBranch,
  CheckSquare,
  FileText,
  Settings,
  Download,
  TrendingUp,
  TrendingDown,
  BarChart3,
} from "lucide-react";
import useUser from "@/utils/useUser";

export default function ReportingPage() {
  const { data: user, loading: userLoading } = useUser();
  const [selectedLine, setSelectedLine] = useState(null);
  const [lines, setLines] = useState([]);
  const [reportData, setReportData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!userLoading && !user) {
      if (typeof window !== "undefined") {
        window.location.href = "/account/signin";
      }
    }
  }, [user, userLoading]);

  useEffect(() => {
    const fetchLines = async () => {
      try {
        const response = await fetch("/api/production-lines");
        if (response.ok) {
          const data = await response.json();
          setLines(data.lines || []);
          if (data.lines && data.lines.length > 0) {
            setSelectedLine(data.lines[0].id);
          }
        }
      } catch (error) {
        console.error("Error fetching lines:", error);
      }
    };
    fetchLines();
  }, []);

  useEffect(() => {
    if (selectedLine) {
      fetchReportData();
    }
  }, [selectedLine]);

  const fetchReportData = async () => {
    setLoading(true);
    try {
      const [kpisRes, amdecRes, actionsRes] = await Promise.all([
        fetch(`/api/kpis?lineId=${selectedLine}&days=30`),
        fetch(`/api/amdec?lineId=${selectedLine}`),
        fetch(`/api/actions?lineId=${selectedLine}`),
      ]);

      const kpis = kpisRes.ok ? await kpisRes.json() : null;
      const amdec = amdecRes.ok ? await amdecRes.json() : null;
      const actions = actionsRes.ok ? await actionsRes.json() : null;

      setReportData({ kpis, amdec, actions });
    } catch (error) {
      console.error("Error fetching report data:", error);
    } finally {
      setLoading(false);
    }
  };

  if (userLoading || !user) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-[#F8FAFC]">
        <div className="text-slate-600">Chargement...</div>
      </div>
    );
  }

  const selectedLineName = lines.find((l) => l.id === selectedLine)?.name || "";

  return (
    <div className="min-h-screen bg-[#F8FAFC] font-inter">
      <header className="fixed top-0 left-0 right-0 z-10 flex items-center justify-between px-4 md:px-6 h-16 bg-white shadow-sm">
        <div className="hidden md:flex items-center">
          <span className="text-[20px] font-medium text-slate-700">
            ProcessFlow Smart
          </span>
        </div>

        <div className="flex-1 mx-4 max-w-lg">
          <div className="flex items-center bg-gray-100 rounded-full px-4 py-2">
            <Search className="w-4 h-4 text-slate-400" />
            <select
              value={selectedLine || ""}
              onChange={(e) => setSelectedLine(parseInt(e.target.value))}
              className="flex-1 bg-transparent text-sm pl-2 outline-none cursor-pointer"
            >
              <option value="">Sélectionner une ligne</option>
              {lines.map((line) => (
                <option key={line.id} value={line.id}>
                  {line.name}
                </option>
              ))}
            </select>
            <ChevronDown className="w-4 h-4 text-slate-400" />
          </div>
        </div>

        <div className="flex items-center space-x-4">
          <div className="hidden sm:flex items-center text-sm font-medium text-slate-600">
            <User className="w-5 h-5 mr-2 text-slate-400" />
            {user.name || user.email}
          </div>
          <button className="relative p-2 rounded-full hover:bg-gray-100">
            <Bell className="w-5 h-5 text-slate-400" />
          </button>
        </div>
      </header>

      <aside className="hidden md:flex fixed top-16 left-0 flex-col items-center w-16 py-6 space-y-4 h-[calc(100vh-4rem)] bg-white border-r border-gray-100">
        <a
          href="/"
          className="p-3 rounded-full bg-white shadow ring-1 ring-gray-100 text-slate-400 hover:text-violet-500"
        >
          <LayoutDashboard className="w-5 h-5" />
        </a>
        <a
          href="/amdec"
          className="p-3 rounded-full bg-white shadow ring-1 ring-gray-100 text-slate-400 hover:text-violet-500"
        >
          <AlertTriangle className="w-5 h-5" />
        </a>
        <a
          href="/actions"
          className="p-3 rounded-full bg-white shadow ring-1 ring-gray-100 text-slate-400 hover:text-violet-500"
        >
          <CheckSquare className="w-5 h-5" />
        </a>
        <button className="p-3 rounded-full shadow ring-1 ring-gray-100 bg-violet-500 text-white">
          <FileText className="w-5 h-5" />
        </button>
        <a
          href="/vsm"
          className="p-3 rounded-full bg-white shadow ring-1 ring-gray-100 text-slate-400 hover:text-violet-500"
        >
          <GitBranch className="w-5 h-5" />
        </a>
        <div className="flex-1"></div>
        <a
          href="/settings"
          className="p-3 rounded-full bg-white shadow ring-1 ring-gray-100 text-slate-400 hover:text-violet-500"
        >
          <Settings className="w-5 h-5" />
        </a>
        <a
          href="/account/logout"
          className="p-3 rounded-full bg-white shadow ring-1 ring-gray-100 text-slate-400 hover:text-violet-500"
        >
          <LogOut className="w-5 h-5" />
        </a>
      </aside>

      <main className="pt-16 md:pl-16">
        <div className="p-6">
          <div className="flex justify-between items-center mb-6">
            <div>
              <h2 className="text-2xl font-medium text-slate-700">
                Reporting Intelligent
              </h2>
              <p className="text-sm text-slate-500 mt-1">
                Synthèse décisionnelle pour {selectedLineName}
              </p>
            </div>
            <button className="flex items-center space-x-2 bg-violet-500 text-white px-4 py-2 rounded-lg hover:bg-violet-600 transition-colors">
              <Download className="w-4 h-4" />
              <span>Exporter PDF</span>
            </button>
          </div>

          {loading ? (
            <div className="text-center py-20 text-slate-500">
              Chargement...
            </div>
          ) : !reportData ? (
            <div className="text-center py-20 text-slate-500">
              Aucune donnée disponible
            </div>
          ) : (
            <div className="space-y-6">
              {/* Executive Summary */}
              <div className="bg-white rounded-[14px] p-6 shadow-sm border border-gray-100">
                <h3 className="text-lg font-medium text-slate-700 mb-4">
                  Synthèse Exécutive
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div>
                    <div className="text-sm text-slate-500 mb-1">
                      Performance Globale
                    </div>
                    <div className="text-2xl font-medium text-slate-700">
                      {reportData.kpis?.latest?.oee?.toFixed(1)}% OEE
                    </div>
                    <div className="flex items-center mt-1 text-sm">
                      {reportData.kpis?.trends?.oee?.isPositive ? (
                        <TrendingUp className="w-4 h-4 text-green-500 mr-1" />
                      ) : (
                        <TrendingDown className="w-4 h-4 text-red-500 mr-1" />
                      )}
                      <span
                        className={
                          reportData.kpis?.trends?.oee?.isPositive
                            ? "text-green-600"
                            : "text-red-600"
                        }
                      >
                        {Math.abs(
                          reportData.kpis?.trends?.oee?.change || 0,
                        ).toFixed(1)}
                        %
                      </span>
                    </div>
                  </div>

                  <div>
                    <div className="text-sm text-slate-500 mb-1">
                      Risques AMDEC
                    </div>
                    <div className="text-2xl font-medium text-slate-700">
                      {reportData.amdec?.analysis?.filter(
                        (a) => a.status === "open",
                      ).length || 0}
                    </div>
                    <div className="text-sm text-slate-500 mt-1">
                      risques ouverts
                    </div>
                  </div>

                  <div>
                    <div className="text-sm text-slate-500 mb-1">
                      Actions en cours
                    </div>
                    <div className="text-2xl font-medium text-slate-700">
                      {reportData.actions?.actions?.filter(
                        (a) => a.status === "in_progress",
                      ).length || 0}
                    </div>
                    <div className="text-sm text-slate-500 mt-1">
                      actions actives
                    </div>
                  </div>
                </div>
              </div>

              {/* KPI Summary */}
              <div className="bg-white rounded-[14px] p-6 shadow-sm border border-gray-100">
                <h3 className="text-lg font-medium text-slate-700 mb-4">
                  Indicateurs Clés de Performance
                </h3>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  <div className="p-4 bg-gray-50 rounded-lg">
                    <div className="text-xs text-slate-500 mb-1">OEE</div>
                    <div className="text-lg font-medium text-slate-700">
                      {reportData.kpis?.latest?.oee?.toFixed(1)}%
                    </div>
                  </div>
                  <div className="p-4 bg-gray-50 rounded-lg">
                    <div className="text-xs text-slate-500 mb-1">TRS</div>
                    <div className="text-lg font-medium text-slate-700">
                      {reportData.kpis?.latest?.trs?.toFixed(1)}%
                    </div>
                  </div>
                  <div className="p-4 bg-gray-50 rounded-lg">
                    <div className="text-xs text-slate-500 mb-1">
                      Taux de rebut
                    </div>
                    <div className="text-lg font-medium text-slate-700">
                      {reportData.kpis?.latest?.defect_rate?.toFixed(2)}%
                    </div>
                  </div>
                  <div className="p-4 bg-gray-50 rounded-lg">
                    <div className="text-xs text-slate-500 mb-1">
                      Production
                    </div>
                    <div className="text-lg font-medium text-slate-700">
                      {reportData.kpis?.latest?.production_volume?.toLocaleString()}{" "}
                      unités
                    </div>
                  </div>
                  <div className="p-4 bg-gray-50 rounded-lg">
                    <div className="text-xs text-slate-500 mb-1">
                      Temps cycle
                    </div>
                    <div className="text-lg font-medium text-slate-700">
                      {reportData.kpis?.latest?.cycle_time} sec
                    </div>
                  </div>
                  <div className="p-4 bg-gray-50 rounded-lg">
                    <div className="text-xs text-slate-500 mb-1">
                      Temps d'arrêt
                    </div>
                    <div className="text-lg font-medium text-slate-700">
                      {reportData.kpis?.latest?.downtime_minutes} min
                    </div>
                  </div>
                </div>
              </div>

              {/* Recommendations */}
              <div className="bg-white rounded-[14px] p-6 shadow-sm border border-gray-100">
                <h3 className="text-lg font-medium text-slate-700 mb-4">
                  Recommandations Stratégiques
                </h3>
                <div className="space-y-3">
                  {reportData.kpis?.recommendations?.map((rec, index) => (
                    <div
                      key={index}
                      className="flex items-start space-x-3 p-3 bg-violet-50 rounded-lg"
                    >
                      <BarChart3 className="w-5 h-5 text-violet-500 mt-0.5 flex-shrink-0" />
                      <p className="text-sm text-slate-700">{rec}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Critical Issues */}
              {reportData.amdec?.analysis?.filter((a) => a.npr >= 200).length >
                0 && (
                <div className="bg-white rounded-[14px] p-6 shadow-sm border border-red-200">
                  <h3 className="text-lg font-medium text-red-700 mb-4">
                    Risques Critiques (NPR ≥ 200)
                  </h3>
                  <div className="space-y-3">
                    {reportData.amdec.analysis
                      .filter((a) => a.npr >= 200)
                      .map((item) => (
                        <div key={item.id} className="p-4 bg-red-50 rounded-lg">
                          <div className="flex justify-between items-start mb-2">
                            <div className="font-medium text-slate-700">
                              {item.process_name}
                            </div>
                            <span className="px-2 py-1 bg-red-500 text-white text-xs rounded-full">
                              NPR: {item.npr}
                            </span>
                          </div>
                          <div className="text-sm text-slate-600">
                            {item.failure_mode}
                          </div>
                        </div>
                      ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </main>

      <style jsx global>{`
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap');
        .font-inter { font-family: 'Inter', sans-serif; }
      `}</style>
    </div>
  );
}
