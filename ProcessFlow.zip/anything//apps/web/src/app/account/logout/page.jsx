"use client";

import useAuth from "@/utils/useAuth";
import { LogOut } from "lucide-react";

export default function LogoutPage() {
  const { signOut } = useAuth();

  const handleSignOut = async () => {
    await signOut({
      callbackUrl: "/account/signin",
      redirect: true,
    });
  };

  return (
    <div className="flex min-h-screen w-full items-center justify-center bg-[#F8FAFC] p-4">
      <div className="w-full max-w-md rounded-[14px] bg-white p-8 shadow-sm border border-gray-100">
        <div className="flex items-center justify-center mb-8">
          <div className="p-3 rounded-full bg-violet-500">
            <LogOut className="w-6 h-6 text-white" />
          </div>
        </div>

        <h1 className="mb-8 text-center text-2xl font-medium text-slate-700">
          Déconnexion
        </h1>

        <button
          onClick={handleSignOut}
          className="w-full rounded-lg bg-violet-500 px-4 py-3 text-sm font-medium text-white transition-colors hover:bg-violet-600 focus:outline-none focus:ring-2 focus:ring-violet-500 focus:ring-offset-2"
        >
          Se déconnecter
        </button>
      </div>
    </div>
  );
}
