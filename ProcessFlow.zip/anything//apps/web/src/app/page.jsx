"use client";

import { useState, useEffect } from "react";
import {
  Menu,
  X,
  Bell,
  User,
  Search,
  ChevronDown,
  TrendingUp,
  TrendingDown,
  LogOut,
  LayoutDashboard,
  AlertTriangle,
  GitBranch,
  CheckSquare,
  FileText,
  Settings,
  HelpCircle,
  MoreVertical,
} from "lucide-react";
import useUser from "@/utils/useUser";

export default function Dashboard() {
  const { data: user, loading: userLoading } = useUser();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [selectedSite, setSelectedSite] = useState(null);
  const [selectedLine, setSelectedLine] = useState(null);
  const [sites, setSites] = useState([]);
  const [lines, setLines] = useState([]);
  const [kpiData, setKpiData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [activeModule, setActiveModule] = useState("dashboard");

  useEffect(() => {
    if (!userLoading && !user) {
      if (typeof window !== "undefined") {
        window.location.href = "/account/signin";
      }
    }
  }, [user, userLoading]);

  useEffect(() => {
    const fetchSites = async () => {
      try {
        const response = await fetch("/api/sites");
        if (response.ok) {
          const data = await response.json();
          setSites(data.sites || []);
          if (data.sites && data.sites.length > 0) {
            setSelectedSite(data.sites[0].id);
          }
        }
      } catch (error) {
        console.error("Error fetching sites:", error);
      }
    };
    fetchSites();
  }, []);

  useEffect(() => {
    if (selectedSite) {
      const fetchLines = async () => {
        try {
          const response = await fetch(
            `/api/production-lines?siteId=${selectedSite}`,
          );
          if (response.ok) {
            const data = await response.json();
            setLines(data.lines || []);
            if (data.lines && data.lines.length > 0) {
              setSelectedLine(data.lines[0].id);
            }
          }
        } catch (error) {
          console.error("Error fetching lines:", error);
        }
      };
      fetchLines();
    }
  }, [selectedSite]);

  useEffect(() => {
    if (selectedLine) {
      const fetchKPIs = async () => {
        setLoading(true);
        try {
          const response = await fetch(
            `/api/kpis?lineId=${selectedLine}&days=30`,
          );
          if (response.ok) {
            const data = await response.json();
            setKpiData(data);
          }
        } catch (error) {
          console.error("Error fetching KPIs:", error);
        } finally {
          setLoading(false);
        }
      };
      fetchKPIs();
    }
  }, [selectedLine]);

  if (userLoading || !user) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-[#F8FAFC]">
        <div className="text-slate-600">Chargement...</div>
      </div>
    );
  }

  const selectedLineName = lines.find((l) => l.id === selectedLine)?.name || "";
  const selectedSiteName = sites.find((s) => s.id === selectedSite)?.name || "";

  return (
    <div className="min-h-screen bg-[#F8FAFC] font-inter">
      {/* Top Bar */}
      <header className="fixed top-0 left-0 right-0 z-10 flex items-center justify-between px-4 md:px-6 h-16 bg-white shadow-sm">
        <button
          className="md:hidden p-2 rounded-full hover:bg-gray-100"
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          aria-label="Toggle menu"
        >
          <Menu className="w-5 h-5 stroke-2 text-slate-500" />
        </button>

        <div className="hidden md:flex items-center space-x-3">
          <img
            src="https://ucarecdn.com/cd7d03a9-be89-4870-a09b-27cf834c2f34/-/format/auto/"
            alt="ProcessFlow Logo"
            className="w-10 h-10"
          />
          <span className="text-[20px] font-medium text-slate-700">
            ProcessFlow
          </span>
        </div>

        {/* Site/Line Selector */}
        <div className="flex-1 mx-4 max-w-lg">
          <div className="flex items-center bg-gray-100 rounded-full px-4 py-2">
            <Search className="w-4 h-4 text-slate-400" />
            <select
              value={selectedLine || ""}
              onChange={(e) => setSelectedLine(parseInt(e.target.value))}
              className="flex-1 bg-transparent text-sm pl-2 outline-none cursor-pointer"
            >
              <option value="">Sélectionner une ligne</option>
              {lines.map((line) => (
                <option key={line.id} value={line.id}>
                  {selectedSiteName} - {line.name}
                </option>
              ))}
            </select>
            <ChevronDown className="w-4 h-4 text-slate-400" />
          </div>
        </div>

        {/* Right cluster */}
        <div className="flex items-center space-x-4">
          <div className="hidden sm:flex items-center text-sm font-medium text-slate-600">
            <User className="w-5 h-5 mr-2 text-slate-400" />
            {user.name || user.email}
          </div>
          <button
            className="relative p-2 rounded-full hover:bg-gray-100"
            aria-label="Notifications"
          >
            <Bell className="w-5 h-5 text-slate-400" />
            <span className="absolute top-1 right-1 h-2 w-2 rounded-full bg-orange-500"></span>
          </button>
        </div>
      </header>

      {/* Mobile Menu Overlay */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-20 md:hidden">
          <div
            className="fixed inset-0 bg-black bg-opacity-50"
            onClick={() => setMobileMenuOpen(false)}
          ></div>
          <div className="fixed top-0 left-0 w-64 h-full bg-white shadow-lg">
            <div className="p-4">
              <button
                onClick={() => setMobileMenuOpen(false)}
                className="p-2 rounded-full hover:bg-gray-100"
                aria-label="Close menu"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <nav className="px-4 space-y-4">
              <a
                href="#"
                onClick={() => {
                  setActiveModule("dashboard");
                  setMobileMenuOpen(false);
                }}
                className="block py-2 text-slate-600 hover:text-violet-500"
              >
                Dashboard
              </a>
              <a
                href="/amdec"
                className="block py-2 text-slate-600 hover:text-violet-500"
              >
                AMDEC
              </a>
              <a
                href="/actions"
                className="block py-2 text-slate-600 hover:text-violet-500"
              >
                Actions
              </a>
              <a
                href="/reporting"
                className="block py-2 text-slate-600 hover:text-violet-500"
              >
                Reporting
              </a>
            </nav>
          </div>
        </div>
      )}

      {/* Left Navigation Rail */}
      <aside className="hidden md:flex fixed top-16 left-0 flex-col items-center w-16 py-6 space-y-4 h-[calc(100vh-4rem)] bg-white border-r border-gray-100">
        <button
          onClick={() => setActiveModule("dashboard")}
          className={`p-3 rounded-full shadow ring-1 ring-gray-100 ${
            activeModule === "dashboard"
              ? "bg-violet-500 text-white"
              : "bg-white text-slate-400 hover:text-violet-500"
          }`}
          aria-label="Dashboard"
        >
          <LayoutDashboard className="w-5 h-5" />
        </button>
        <a
          href="/amdec"
          className="p-3 rounded-full bg-white shadow ring-1 ring-gray-100 text-slate-400 hover:text-violet-500"
          aria-label="AMDEC"
        >
          <AlertTriangle className="w-5 h-5" />
        </a>
        <a
          href="/actions"
          className="p-3 rounded-full bg-white shadow ring-1 ring-gray-100 text-slate-400 hover:text-violet-500"
          aria-label="Actions"
        >
          <CheckSquare className="w-5 h-5" />
        </a>
        <a
          href="/reporting"
          className="p-3 rounded-full bg-white shadow ring-1 ring-gray-100 text-slate-400 hover:text-violet-500"
          aria-label="Reporting"
        >
          <FileText className="w-5 h-5" />
        </a>
        <a
          href="/vsm"
          className="p-3 rounded-full bg-white shadow ring-1 ring-gray-100 text-slate-400 hover:text-violet-500"
          aria-label="VSM"
        >
          <GitBranch className="w-5 h-5" />
        </a>

        <div className="flex-1"></div>

        <a
          href="/settings"
          className="p-3 rounded-full bg-white shadow ring-1 ring-gray-100 text-slate-400 hover:text-violet-500"
          aria-label="Settings"
        >
          <Settings className="w-5 h-5" />
        </a>
        <a
          href="/account/logout"
          className="p-3 rounded-full bg-white shadow ring-1 ring-gray-100 text-slate-400 hover:text-violet-500"
          aria-label="Logout"
        >
          <LogOut className="w-5 h-5" />
        </a>
      </aside>

      {/* Main Content */}
      <main className="pt-16 md:pl-16 xl:pr-80">
        <div className="p-6">
          <div className="mb-6">
            <h2 className="text-2xl font-medium text-slate-700">
              {selectedLineName || "Tableau de bord"}
            </h2>
            <p className="text-sm text-slate-500 mt-1">
              Performance et indicateurs clés en temps réel
            </p>
          </div>

          {loading ? (
            <div className="text-center py-20 text-slate-500">
              Chargement des données...
            </div>
          ) : !kpiData ? (
            <div className="text-center py-20 text-slate-500">
              Aucune donnée disponible
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-6">
              {/* OEE Card */}
              <KPICard
                title="OEE (Overall Equipment Effectiveness)"
                value={`${kpiData.latest.oee.toFixed(1)}%`}
                change={kpiData.trends.oee.change.toFixed(1)}
                isPositive={kpiData.trends.oee.isPositive}
                label="OEE sur 30 jours"
                alert={kpiData.latest.oee < 65}
                alertMessage="OEE inférieur au seuil recommandé (65%)"
              />

              {/* TRS Card */}
              <KPICard
                title="TRS (Taux de Rendement Synthétique)"
                value={`${kpiData.latest.trs.toFixed(1)}%`}
                change={kpiData.trends.trs.change.toFixed(1)}
                isPositive={kpiData.trends.trs.isPositive}
                label="TRS sur 30 jours"
                alert={kpiData.latest.trs < 70}
                alertMessage="TRS inférieur au seuil recommandé (70%)"
              />

              {/* Defect Rate */}
              <KPICard
                title="Taux de rebut"
                value={`${kpiData.latest.defect_rate.toFixed(2)}%`}
                change={kpiData.trends.defect_rate.change.toFixed(2)}
                isPositive={!kpiData.trends.defect_rate.isPositive}
                label="Rebuts sur 30 jours"
                alert={kpiData.latest.defect_rate > 3}
                alertMessage="Taux de rebut élevé (> 3%)"
              />

              {/* Cycle Time */}
              <KPICard
                title="Temps de cycle moyen"
                value={`${Math.round(kpiData.latest.cycle_time)} sec`}
                change={kpiData.trends.cycle_time.change.toFixed(1)}
                isPositive={!kpiData.trends.cycle_time.isPositive}
                label="Temps de cycle"
              />

              {/* Production Volume */}
              <KPICard
                title="Volume de production"
                value={kpiData.latest.production_volume.toLocaleString()}
                change={kpiData.trends.production_volume.change.toFixed(1)}
                isPositive={kpiData.trends.production_volume.isPositive}
                label="Unités produites"
              />

              {/* Downtime */}
              <KPICard
                title="Temps d'arrêt"
                value={`${Math.round(kpiData.latest.downtime_minutes)} min`}
                change={kpiData.trends.downtime_minutes.change.toFixed(1)}
                isPositive={!kpiData.trends.downtime_minutes.isPositive}
                label="Arrêts quotidiens moyens"
                alert={kpiData.latest.downtime_minutes > 60}
                alertMessage="Temps d'arrêt élevé (> 60 min)"
              />
            </div>
          )}
        </div>
      </main>

      {/* Right Sidebar */}
      <aside className="hidden xl:block fixed right-0 top-16 bottom-0 w-80 overflow-y-auto bg-white border-l border-gray-200">
        {kpiData && (
          <>
            {/* Alerts Summary */}
            <section className="bg-white rounded-[12px] md:rounded-[14px] p-5 m-4 shadow-sm border border-transparent">
              <div className="flex justify-between items-start">
                <h4 className="text-xs text-slate-500 font-medium">
                  Alertes actives
                </h4>
                <div className="h-9 w-20 bg-gradient-to-r from-orange-400 to-orange-500 rounded flex items-center justify-center">
                  <AlertTriangle className="w-4 h-4 text-white" />
                </div>
              </div>
              <p className="text-2xl font-medium text-slate-600 mt-1">
                {kpiData.alerts?.length || 0}
              </p>
              <div className="flex justify-between items-center border-t pt-3 mt-4">
                <span className="text-sm text-slate-500">
                  Nécessitent une action
                </span>
                <a
                  href="/alerts"
                  className="text-sm font-medium text-slate-600 hover:text-violet-500"
                >
                  Voir détails
                </a>
              </div>
            </section>

            {/* Performance Summary */}
            <section className="bg-white rounded-[12px] md:rounded-[14px] p-5 m-4 shadow-sm border border-transparent">
              <h4 className="text-xs text-slate-500 font-medium mb-4">
                Performance globale
              </h4>
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-slate-600">OEE moyen</span>
                  <span className="text-sm font-medium text-slate-700">
                    {kpiData.trends.oee.average.toFixed(1)}%
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-slate-600">
                    Production totale
                  </span>
                  <span className="text-sm font-medium text-slate-700">
                    {(
                      kpiData.trends.production_volume.total || 0
                    ).toLocaleString()}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-slate-600">Disponibilité</span>
                  <span className="text-sm font-medium text-green-600">
                    {(
                      (1 - kpiData.latest.downtime_minutes / (24 * 60)) *
                      100
                    ).toFixed(1)}
                    %
                  </span>
                </div>
              </div>
            </section>

            {/* Recommendations */}
            <section className="bg-white rounded-[12px] md:rounded-[14px] p-5 m-4 shadow-sm border border-transparent">
              <h4 className="text-xs text-slate-500 font-medium mb-4">
                Recommandations intelligentes
              </h4>
              <div className="space-y-4">
                {kpiData.recommendations?.map((rec, index) => (
                  <div key={index} className="flex items-start space-x-3">
                    <div className="w-2 h-2 rounded-full bg-violet-500 mt-1.5"></div>
                    <p className="text-sm text-slate-600">{rec}</p>
                  </div>
                ))}
              </div>
            </section>
          </>
        )}
      </aside>

      <style jsx global>{`
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap');
        .font-inter { font-family: 'Inter', sans-serif; }
      `}</style>
    </div>
  );
}

function KPICard({
  title,
  value,
  change,
  isPositive,
  label,
  alert,
  alertMessage,
}) {
  return (
    <article className="bg-white rounded-[12px] md:rounded-[14px] p-6 shadow-sm border border-transparent">
      <div className="flex justify-between items-start">
        <h3 className="text-xs font-medium text-slate-500">{title}</h3>
        <div className="flex space-x-2">
          {alert && (
            <div className="relative group">
              <AlertTriangle className="w-4 h-4 text-orange-500" />
              <div className="absolute right-0 top-6 w-48 bg-slate-800 text-white text-xs p-2 rounded opacity-0 group-hover:opacity-100 transition-opacity z-10 pointer-events-none">
                {alertMessage}
              </div>
            </div>
          )}
          <button aria-label="More options">
            <MoreVertical className="w-4 h-4 text-slate-400" />
          </button>
        </div>
      </div>

      <div className="flex justify-between items-center mt-2">
        <p className="text-2xl font-medium text-slate-600">{value}</p>
        {change && (
          <div
            className={`flex items-center space-x-1 ${
              isPositive ? "text-green-500" : "text-rose-500"
            }`}
          >
            {isPositive ? (
              <TrendingUp className="w-4 h-4" />
            ) : (
              <TrendingDown className="w-4 h-4" />
            )}
            <span className="font-medium text-sm">
              {Math.abs(parseFloat(change))}%
            </span>
          </div>
        )}
      </div>

      <p className="text-xs font-medium text-slate-400 tracking-wide uppercase mt-4">
        {label}
      </p>
    </article>
  );
}
