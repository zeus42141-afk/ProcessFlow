"use client";

import { useState, useEffect } from "react";
import {
  Menu,
  Bell,
  User,
  Search,
  ChevronDown,
  LogOut,
  LayoutDashboard,
  AlertTriangle,
  GitBranch,
  CheckSquare,
  FileText,
  Settings,
  Building2,
  Factory,
  Save,
  Plus,
} from "lucide-react";
import useUser from "@/utils/useUser";

export default function SettingsPage() {
  const { data: user, loading: userLoading } = useUser();
  const [sites, setSites] = useState([]);
  const [lines, setLines] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showSiteModal, setShowSiteModal] = useState(false);
  const [showLineModal, setShowLineModal] = useState(false);
  const [siteForm, setSiteForm] = useState({ name: "", location: "" });
  const [lineForm, setLineForm] = useState({
    siteId: "",
    name: "",
    description: "",
  });

  useEffect(() => {
    if (!userLoading && !user) {
      if (typeof window !== "undefined") {
        window.location.href = "/account/signin";
      }
    }
  }, [user, userLoading]);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    setLoading(true);
    try {
      const [sitesRes, linesRes] = await Promise.all([
        fetch("/api/sites"),
        fetch("/api/production-lines"),
      ]);

      if (sitesRes.ok) {
        const sitesData = await sitesRes.json();
        setSites(sitesData.sites || []);
      }

      if (linesRes.ok) {
        const linesData = await linesRes.json();
        setLines(linesData.lines || []);
      }
    } catch (error) {
      console.error("Error fetching data:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleCreateSite = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch("/api/sites", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(siteForm),
      });

      if (response.ok) {
        setShowSiteModal(false);
        setSiteForm({ name: "", location: "" });
        fetchData();
      }
    } catch (error) {
      console.error("Error creating site:", error);
    }
  };

  const handleCreateLine = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch("/api/production-lines", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(lineForm),
      });

      if (response.ok) {
        setShowLineModal(false);
        setLineForm({ siteId: "", name: "", description: "" });
        fetchData();
      }
    } catch (error) {
      console.error("Error creating line:", error);
    }
  };

  if (userLoading || !user) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-[#F8FAFC]">
        <div className="text-slate-600">Chargement...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F8FAFC] font-inter">
      <header className="fixed top-0 left-0 right-0 z-10 flex items-center justify-between px-4 md:px-6 h-16 bg-white shadow-sm">
        <div className="hidden md:flex items-center">
          <span className="text-[20px] font-medium text-slate-700">
            ProcessFlow Smart
          </span>
        </div>

        <div className="flex-1 mx-4 max-w-lg"></div>

        <div className="flex items-center space-x-4">
          <div className="hidden sm:flex items-center text-sm font-medium text-slate-600">
            <User className="w-5 h-5 mr-2 text-slate-400" />
            {user.name || user.email}
          </div>
          <button className="relative p-2 rounded-full hover:bg-gray-100">
            <Bell className="w-5 h-5 text-slate-400" />
          </button>
        </div>
      </header>

      <aside className="hidden md:flex fixed top-16 left-0 flex-col items-center w-16 py-6 space-y-4 h-[calc(100vh-4rem)] bg-white border-r border-gray-100">
        <a
          href="/"
          className="p-3 rounded-full bg-white shadow ring-1 ring-gray-100 text-slate-400 hover:text-violet-500"
        >
          <LayoutDashboard className="w-5 h-5" />
        </a>
        <a
          href="/amdec"
          className="p-3 rounded-full bg-white shadow ring-1 ring-gray-100 text-slate-400 hover:text-violet-500"
        >
          <AlertTriangle className="w-5 h-5" />
        </a>
        <a
          href="/actions"
          className="p-3 rounded-full bg-white shadow ring-1 ring-gray-100 text-slate-400 hover:text-violet-500"
        >
          <CheckSquare className="w-5 h-5" />
        </a>
        <a
          href="/reporting"
          className="p-3 rounded-full bg-white shadow ring-1 ring-gray-100 text-slate-400 hover:text-violet-500"
        >
          <FileText className="w-5 h-5" />
        </a>
        <a
          href="/vsm"
          className="p-3 rounded-full bg-white shadow ring-1 ring-gray-100 text-slate-400 hover:text-violet-500"
        >
          <GitBranch className="w-5 h-5" />
        </a>
        <div className="flex-1"></div>
        <button className="p-3 rounded-full shadow ring-1 ring-gray-100 bg-violet-500 text-white">
          <Settings className="w-5 h-5" />
        </button>
        <a
          href="/account/logout"
          className="p-3 rounded-full bg-white shadow ring-1 ring-gray-100 text-slate-400 hover:text-violet-500"
        >
          <LogOut className="w-5 h-5" />
        </a>
      </aside>

      <main className="pt-16 md:pl-16">
        <div className="p-6">
          <div className="mb-6">
            <h2 className="text-2xl font-medium text-slate-700">Paramètres</h2>
            <p className="text-sm text-slate-500 mt-1">
              Gestion des sites et lignes de production
            </p>
          </div>

          {/* Sites Section */}
          <div className="mb-8">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-medium text-slate-700">
                Sites de production
              </h3>
              <button
                onClick={() => setShowSiteModal(true)}
                className="flex items-center space-x-2 bg-violet-500 text-white px-4 py-2 rounded-lg hover:bg-violet-600 transition-colors"
              >
                <Plus className="w-4 h-4" />
                <span>Nouveau site</span>
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {loading ? (
                <div className="col-span-full text-center py-12 text-slate-500">
                  Chargement...
                </div>
              ) : sites.length === 0 ? (
                <div className="col-span-full text-center py-12 text-slate-500">
                  Aucun site
                </div>
              ) : (
                sites.map((site) => (
                  <div
                    key={site.id}
                    className="bg-white rounded-[14px] p-6 shadow-sm border border-gray-100"
                  >
                    <div className="flex items-start space-x-3">
                      <div className="p-2 bg-violet-100 rounded-lg">
                        <Building2 className="w-5 h-5 text-violet-500" />
                      </div>
                      <div className="flex-1">
                        <h4 className="font-medium text-slate-700">
                          {site.name}
                        </h4>
                        <p className="text-sm text-slate-500 mt-1">
                          {site.location || "Aucune localisation"}
                        </p>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Production Lines Section */}
          <div>
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-medium text-slate-700">
                Lignes de production
              </h3>
              <button
                onClick={() => setShowLineModal(true)}
                className="flex items-center space-x-2 bg-violet-500 text-white px-4 py-2 rounded-lg hover:bg-violet-600 transition-colors"
              >
                <Plus className="w-4 h-4" />
                <span>Nouvelle ligne</span>
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {loading ? (
                <div className="col-span-full text-center py-12 text-slate-500">
                  Chargement...
                </div>
              ) : lines.length === 0 ? (
                <div className="col-span-full text-center py-12 text-slate-500">
                  Aucune ligne
                </div>
              ) : (
                lines.map((line) => {
                  const site = sites.find((s) => s.id === line.site_id);
                  return (
                    <div
                      key={line.id}
                      className="bg-white rounded-[14px] p-6 shadow-sm border border-gray-100"
                    >
                      <div className="flex items-start space-x-3">
                        <div className="p-2 bg-blue-100 rounded-lg">
                          <Factory className="w-5 h-5 text-blue-500" />
                        </div>
                        <div className="flex-1">
                          <h4 className="font-medium text-slate-700">
                            {line.name}
                          </h4>
                          <p className="text-sm text-slate-500 mt-1">
                            {site?.name || "Site inconnu"}
                          </p>
                          {line.description && (
                            <p className="text-xs text-slate-400 mt-2">
                              {line.description}
                            </p>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>

          {/* Footer with credits */}
          <div className="mt-12 pt-6 border-t border-gray-200">
            <div className="text-center text-sm text-slate-500">
              <p>
                Développé par{" "}
                <span className="font-medium text-slate-700">
                  Mohamed Aziz RIAHI
                </span>
              </p>
              <p className="mt-1 text-xs">
                ProcessFlow © 2026 - Tous droits réservés
              </p>
            </div>
          </div>
        </div>
      </main>

      {/* Site Modal */}
      {showSiteModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50">
          <div className="bg-white rounded-[14px] p-8 max-w-md w-full mx-4">
            <h3 className="text-xl font-medium text-slate-700 mb-6">
              Nouveau site
            </h3>
            <form onSubmit={handleCreateSite} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-600 mb-2">
                  Nom du site
                </label>
                <input
                  type="text"
                  required
                  value={siteForm.name}
                  onChange={(e) =>
                    setSiteForm({ ...siteForm, name: e.target.value })
                  }
                  className="w-full rounded-lg border border-gray-200 px-4 py-2 text-sm outline-none focus:border-violet-500 focus:ring-1 focus:ring-violet-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-600 mb-2">
                  Localisation
                </label>
                <input
                  type="text"
                  value={siteForm.location}
                  onChange={(e) =>
                    setSiteForm({ ...siteForm, location: e.target.value })
                  }
                  className="w-full rounded-lg border border-gray-200 px-4 py-2 text-sm outline-none focus:border-violet-500 focus:ring-1 focus:ring-violet-500"
                />
              </div>

              <div className="flex justify-end space-x-3 mt-6">
                <button
                  type="button"
                  onClick={() => setShowSiteModal(false)}
                  className="px-4 py-2 rounded-lg text-sm font-medium text-slate-600 bg-gray-100 hover:bg-gray-200 transition-colors"
                >
                  Annuler
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-lg text-sm font-medium text-white bg-violet-500 hover:bg-violet-600 transition-colors"
                >
                  Créer
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Line Modal */}
      {showLineModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50">
          <div className="bg-white rounded-[14px] p-8 max-w-md w-full mx-4">
            <h3 className="text-xl font-medium text-slate-700 mb-6">
              Nouvelle ligne de production
            </h3>
            <form onSubmit={handleCreateLine} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-600 mb-2">
                  Site
                </label>
                <select
                  required
                  value={lineForm.siteId}
                  onChange={(e) =>
                    setLineForm({ ...lineForm, siteId: e.target.value })
                  }
                  className="w-full rounded-lg border border-gray-200 px-4 py-2 text-sm outline-none focus:border-violet-500 focus:ring-1 focus:ring-violet-500"
                >
                  <option value="">Sélectionner un site</option>
                  {sites.map((site) => (
                    <option key={site.id} value={site.id}>
                      {site.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-600 mb-2">
                  Nom de la ligne
                </label>
                <input
                  type="text"
                  required
                  value={lineForm.name}
                  onChange={(e) =>
                    setLineForm({ ...lineForm, name: e.target.value })
                  }
                  className="w-full rounded-lg border border-gray-200 px-4 py-2 text-sm outline-none focus:border-violet-500 focus:ring-1 focus:ring-violet-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-600 mb-2">
                  Description
                </label>
                <textarea
                  value={lineForm.description}
                  onChange={(e) =>
                    setLineForm({ ...lineForm, description: e.target.value })
                  }
                  className="w-full rounded-lg border border-gray-200 px-4 py-2 text-sm outline-none focus:border-violet-500 focus:ring-1 focus:ring-violet-500"
                  rows="3"
                />
              </div>

              <div className="flex justify-end space-x-3 mt-6">
                <button
                  type="button"
                  onClick={() => setShowLineModal(false)}
                  className="px-4 py-2 rounded-lg text-sm font-medium text-slate-600 bg-gray-100 hover:bg-gray-200 transition-colors"
                >
                  Annuler
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-lg text-sm font-medium text-white bg-violet-500 hover:bg-violet-600 transition-colors"
                >
                  Créer
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      <style jsx global>{`
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap');
        .font-inter { font-family: 'Inter', sans-serif; }
      `}</style>
    </div>
  );
}
