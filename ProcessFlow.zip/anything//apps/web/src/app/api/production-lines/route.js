import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function GET(request) {
  try {
    const session = await auth();
    if (!session || !session.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const siteId = searchParams.get("siteId");

    let lines;
    if (siteId) {
      lines = await sql`
        SELECT id, site_id, name, description, created_at
        FROM production_lines
        WHERE site_id = ${parseInt(siteId)}
        ORDER BY name ASC
      `;
    } else {
      lines = await sql`
        SELECT id, site_id, name, description, created_at
        FROM production_lines
        ORDER BY name ASC
      `;
    }

    return Response.json({ lines });
  } catch (error) {
    console.error("Error fetching production lines:", error);
    return Response.json({ error: "Internal server error" }, { status: 500 });
  }
}

export async function POST(request) {
  try {
    const session = await auth();
    if (!session || !session.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await request.json();
    const { siteId, name, description } = body;

    if (!siteId || !name) {
      return Response.json(
        { error: "Site ID and name are required" },
        { status: 400 },
      );
    }

    const result = await sql`
      INSERT INTO production_lines (site_id, name, description)
      VALUES (${siteId}, ${name}, ${description || null})
      RETURNING id, site_id, name, description, created_at
    `;

    return Response.json({ line: result[0] });
  } catch (error) {
    console.error("Error creating production line:", error);
    return Response.json({ error: "Internal server error" }, { status: 500 });
  }
}
