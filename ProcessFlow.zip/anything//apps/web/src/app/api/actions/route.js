import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function GET(request) {
  try {
    const session = await auth();
    if (!session || !session.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const lineId = searchParams.get("lineId");

    let actions;
    if (lineId) {
      actions = await sql`
        SELECT 
          id, title, description, action_type, line_id, amdec_id,
          assigned_to, priority, status, estimated_roi, actual_gains,
          start_date, due_date, completion_date, lean_method,
          created_at, updated_at
        FROM improvement_actions
        WHERE line_id = ${parseInt(lineId)}
        ORDER BY 
          CASE priority
            WHEN 'critical' THEN 1
            WHEN 'high' THEN 2
            WHEN 'medium' THEN 3
            ELSE 4
          END,
          due_date ASC NULLS LAST
      `;
    } else {
      actions = await sql`
        SELECT 
          id, title, description, action_type, line_id, amdec_id,
          assigned_to, priority, status, estimated_roi, actual_gains,
          start_date, due_date, completion_date, lean_method,
          created_at, updated_at
        FROM improvement_actions
        ORDER BY 
          CASE priority
            WHEN 'critical' THEN 1
            WHEN 'high' THEN 2
            WHEN 'medium' THEN 3
            ELSE 4
          END,
          due_date ASC NULLS LAST
      `;
    }

    return Response.json({ actions });
  } catch (error) {
    console.error("Error fetching actions:", error);
    return Response.json({ error: "Internal server error" }, { status: 500 });
  }
}

export async function POST(request) {
  try {
    const session = await auth();
    if (!session || !session.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await request.json();
    const {
      lineId,
      title,
      description,
      actionType,
      assignedTo,
      priority,
      estimatedRoi,
      startDate,
      dueDate,
      leanMethod,
    } = body;

    if (!lineId || !title) {
      return Response.json(
        { error: "Line ID and title are required" },
        { status: 400 },
      );
    }

    const result = await sql`
      INSERT INTO improvement_actions (
        line_id, title, description, action_type, assigned_to,
        priority, estimated_roi, start_date, due_date, lean_method
      )
      VALUES (
        ${lineId}, ${title}, ${description || null}, ${actionType || "productivity"},
        ${assignedTo || null}, ${priority || "medium"}, ${estimatedRoi || null},
        ${startDate || null}, ${dueDate || null}, ${leanMethod || null}
      )
      RETURNING id, title, description, action_type, line_id, amdec_id,
                assigned_to, priority, status, estimated_roi, actual_gains,
                start_date, due_date, completion_date, lean_method,
                created_at, updated_at
    `;

    return Response.json({ action: result[0] });
  } catch (error) {
    console.error("Error creating action:", error);
    return Response.json({ error: "Internal server error" }, { status: 500 });
  }
}

export async function PUT(request) {
  try {
    const session = await auth();
    if (!session || !session.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await request.json();
    const { id, status, actualGains, completionDate } = body;

    if (!id) {
      return Response.json({ error: "ID is required" }, { status: 400 });
    }

    const updates = [];
    const values = [];

    if (status) {
      updates.push(`status = $${values.length + 1}`);
      values.push(status);
    }

    if (actualGains !== undefined) {
      updates.push(`actual_gains = $${values.length + 1}`);
      values.push(actualGains);
    }

    if (completionDate) {
      updates.push(`completion_date = $${values.length + 1}`);
      values.push(completionDate);
    }

    if (updates.length === 0) {
      return Response.json({ error: "No fields to update" }, { status: 400 });
    }

    updates.push(`updated_at = CURRENT_TIMESTAMP`);

    const queryStr = `
      UPDATE improvement_actions
      SET ${updates.join(", ")}
      WHERE id = $${values.length + 1}
      RETURNING id, title, description, action_type, line_id, amdec_id,
                assigned_to, priority, status, estimated_roi, actual_gains,
                start_date, due_date, completion_date, lean_method,
                created_at, updated_at
    `;

    const result = await sql(queryStr, [...values, id]);

    return Response.json({ action: result[0] });
  } catch (error) {
    console.error("Error updating action:", error);
    return Response.json({ error: "Internal server error" }, { status: 500 });
  }
}
