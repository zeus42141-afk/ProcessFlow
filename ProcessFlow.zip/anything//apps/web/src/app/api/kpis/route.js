import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function GET(request) {
  try {
    const session = await auth();
    if (!session || !session.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const lineId = searchParams.get("lineId");
    const days = parseInt(searchParams.get("days") || "30");

    if (!lineId) {
      return Response.json({ error: "Line ID is required" }, { status: 400 });
    }

    const records = await sql`
      SELECT 
        id, line_id, recorded_date, oee, trs, defect_rate, 
        cycle_time, production_volume, downtime_minutes, created_at
      FROM kpi_records
      WHERE line_id = ${parseInt(lineId)}
        AND recorded_date >= CURRENT_DATE - ${days}::INTEGER
      ORDER BY recorded_date DESC
    `;

    if (records.length === 0) {
      return Response.json({
        latest: null,
        trends: null,
        alerts: [],
        recommendations: [],
      });
    }

    const latest = records[0];
    const oldRecords = records.slice(-7);

    const calculateTrend = (metricName) => {
      const latestValue = parseFloat(latest[metricName]) || 0;
      const avgOld =
        oldRecords.reduce(
          (sum, r) => sum + (parseFloat(r[metricName]) || 0),
          0,
        ) / oldRecords.length;
      const change = avgOld > 0 ? ((latestValue - avgOld) / avgOld) * 100 : 0;
      const total = records.reduce(
        (sum, r) => sum + (parseFloat(r[metricName]) || 0),
        0,
      );
      const average = total / records.length;

      return {
        change: change,
        isPositive: change > 0,
        average: average,
        total: metricName === "production_volume" ? total : null,
      };
    };

    const trends = {
      oee: calculateTrend("oee"),
      trs: calculateTrend("trs"),
      defect_rate: calculateTrend("defect_rate"),
      cycle_time: calculateTrend("cycle_time"),
      production_volume: calculateTrend("production_volume"),
      downtime_minutes: calculateTrend("downtime_minutes"),
    };

    const alerts = [];
    const recommendations = [];

    if (latest.oee < 65) {
      alerts.push({
        type: "warning",
        metric: "OEE",
        message: "OEE inférieur au seuil recommandé (65%)",
      });
      recommendations.push(
        "Mettre en place un programme TPM pour améliorer la disponibilité des équipements",
      );
    }

    if (latest.trs < 70) {
      alerts.push({
        type: "warning",
        metric: "TRS",
        message: "TRS inférieur au seuil recommandé (70%)",
      });
      recommendations.push(
        "Analyser les micro-arrêts et optimiser les changements de série avec SMED",
      );
    }

    if (latest.defect_rate > 3) {
      alerts.push({
        type: "critical",
        metric: "Rebut",
        message: "Taux de rebut élevé",
      });
      recommendations.push(
        "Implémenter des systèmes Poka-Yoke pour réduire les défauts de qualité",
      );
    }

    if (latest.downtime_minutes > 60) {
      alerts.push({
        type: "warning",
        metric: "Arrêts",
        message: "Temps d'arrêt excessif",
      });
      recommendations.push(
        "Réduire les temps d'arrêt par une maintenance préventive renforcée",
      );
    }

    if (
      trends.production_volume.isPositive &&
      trends.production_volume.change > 5
    ) {
      recommendations.push(
        "Excellente progression de la production. Capitaliser sur ces bonnes pratiques",
      );
    }

    if (recommendations.length === 0) {
      recommendations.push(
        "Performance satisfaisante. Continuer le suivi régulier des indicateurs",
      );
    }

    return Response.json({
      latest: {
        oee: parseFloat(latest.oee),
        trs: parseFloat(latest.trs),
        defect_rate: parseFloat(latest.defect_rate),
        cycle_time: parseInt(latest.cycle_time),
        production_volume: parseInt(latest.production_volume),
        downtime_minutes: parseInt(latest.downtime_minutes),
      },
      trends,
      alerts,
      recommendations,
    });
  } catch (error) {
    console.error("Error fetching KPIs:", error);
    return Response.json({ error: "Internal server error" }, { status: 500 });
  }
}

export async function POST(request) {
  try {
    const session = await auth();
    if (!session || !session.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await request.json();
    const {
      lineId,
      recordedDate,
      oee,
      trs,
      defectRate,
      cycleTime,
      productionVolume,
      downtimeMinutes,
    } = body;

    if (!lineId || !recordedDate) {
      return Response.json(
        { error: "Line ID and recorded date are required" },
        { status: 400 },
      );
    }

    const result = await sql`
      INSERT INTO kpi_records (
        line_id, recorded_date, oee, trs, defect_rate, 
        cycle_time, production_volume, downtime_minutes
      )
      VALUES (
        ${lineId}, ${recordedDate}, ${oee || null}, ${trs || null}, 
        ${defectRate || null}, ${cycleTime || null}, 
        ${productionVolume || null}, ${downtimeMinutes || null}
      )
      RETURNING id, line_id, recorded_date, oee, trs, defect_rate, 
                cycle_time, production_volume, downtime_minutes, created_at
    `;

    return Response.json({ record: result[0] });
  } catch (error) {
    console.error("Error creating KPI record:", error);
    return Response.json({ error: "Internal server error" }, { status: 500 });
  }
}
