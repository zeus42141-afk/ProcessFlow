import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function GET() {
  try {
    const session = await auth();
    if (!session || !session.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const sites = await sql`
      SELECT id, name, location, created_at
      FROM sites
      ORDER BY name ASC
    `;

    return Response.json({ sites });
  } catch (error) {
    console.error("Error fetching sites:", error);
    return Response.json({ error: "Internal server error" }, { status: 500 });
  }
}

export async function POST(request) {
  try {
    const session = await auth();
    if (!session || !session.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await request.json();
    const { name, location } = body;

    if (!name) {
      return Response.json({ error: "Name is required" }, { status: 400 });
    }

    const result = await sql`
      INSERT INTO sites (name, location)
      VALUES (${name}, ${location || null})
      RETURNING id, name, location, created_at
    `;

    return Response.json({ site: result[0] });
  } catch (error) {
    console.error("Error creating site:", error);
    return Response.json({ error: "Internal server error" }, { status: 500 });
  }
}
