import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function GET(request) {
  try {
    const session = await auth();
    if (!session || !session.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const lineId = searchParams.get("lineId");

    let analysis;
    if (lineId) {
      analysis = await sql`
        SELECT 
          id, line_id, process_name, failure_mode, effect, cause,
          severity, occurrence, detection, npr, current_controls,
          recommended_actions, status, priority_score, created_at, updated_at
        FROM amdec_analysis
        WHERE line_id = ${parseInt(lineId)}
        ORDER BY npr DESC, priority_score DESC
      `;
    } else {
      analysis = await sql`
        SELECT 
          id, line_id, process_name, failure_mode, effect, cause,
          severity, occurrence, detection, npr, current_controls,
          recommended_actions, status, priority_score, created_at, updated_at
        FROM amdec_analysis
        ORDER BY npr DESC, priority_score DESC
      `;
    }

    return Response.json({ analysis });
  } catch (error) {
    console.error("Error fetching AMDEC analysis:", error);
    return Response.json({ error: "Internal server error" }, { status: 500 });
  }
}

export async function POST(request) {
  try {
    const session = await auth();
    if (!session || !session.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await request.json();
    const {
      lineId,
      processName,
      failureMode,
      effect,
      cause,
      severity,
      occurrence,
      detection,
      currentControls,
      recommendedActions,
    } = body;

    if (
      !lineId ||
      !processName ||
      !failureMode ||
      !severity ||
      !occurrence ||
      !detection
    ) {
      return Response.json(
        { error: "Required fields missing" },
        { status: 400 },
      );
    }

    const npr = severity * occurrence * detection;
    const priorityScore = npr / 10 + severity * 2;

    const result = await sql`
      INSERT INTO amdec_analysis (
        line_id, process_name, failure_mode, effect, cause,
        severity, occurrence, detection, current_controls,
        recommended_actions, priority_score
      )
      VALUES (
        ${lineId}, ${processName}, ${failureMode}, ${effect || null},
        ${cause || null}, ${severity}, ${occurrence}, ${detection},
        ${currentControls || null}, ${recommendedActions || null}, ${priorityScore}
      )
      RETURNING id, line_id, process_name, failure_mode, effect, cause,
                severity, occurrence, detection, npr, current_controls,
                recommended_actions, status, priority_score, created_at, updated_at
    `;

    return Response.json({ analysis: result[0] });
  } catch (error) {
    console.error("Error creating AMDEC analysis:", error);
    return Response.json({ error: "Internal server error" }, { status: 500 });
  }
}

export async function PUT(request) {
  try {
    const session = await auth();
    if (!session || !session.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await request.json();
    const { id, status } = body;

    if (!id) {
      return Response.json({ error: "ID is required" }, { status: 400 });
    }

    const updates = [];
    const values = [];

    if (status) {
      updates.push(`status = $${values.length + 1}`);
      values.push(status);
    }

    if (updates.length === 0) {
      return Response.json({ error: "No fields to update" }, { status: 400 });
    }

    updates.push(`updated_at = CURRENT_TIMESTAMP`);
    const queryStr = `
      UPDATE amdec_analysis
      SET ${updates.join(", ")}
      WHERE id = $${values.length + 1}
      RETURNING id, line_id, process_name, failure_mode, effect, cause,
                severity, occurrence, detection, npr, current_controls,
                recommended_actions, status, priority_score, created_at, updated_at
    `;

    const result = await sql(queryStr, [...values, id]);

    return Response.json({ analysis: result[0] });
  } catch (error) {
    console.error("Error updating AMDEC analysis:", error);
    return Response.json({ error: "Internal server error" }, { status: 500 });
  }
}
