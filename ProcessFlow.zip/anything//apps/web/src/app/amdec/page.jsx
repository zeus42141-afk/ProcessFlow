"use client";

import { useState, useEffect } from "react";
import {
  Menu,
  X,
  Bell,
  User,
  Search,
  ChevronDown,
  LogOut,
  LayoutDashboard,
  AlertTriangle,
  GitBranch,
  CheckSquare,
  FileText,
  Settings,
  Plus,
  Filter,
  TrendingUp,
  TrendingDown,
  MoreVertical,
  Eye,
  Edit,
} from "lucide-react";
import useUser from "@/utils/useUser";

export default function AMDECPage() {
  const { data: user, loading: userLoading } = useUser();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [selectedLine, setSelectedLine] = useState(null);
  const [lines, setLines] = useState([]);
  const [amdecData, setAmdecData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filterStatus, setFilterStatus] = useState("all");
  const [showModal, setShowModal] = useState(false);
  const [formData, setFormData] = useState({
    processName: "",
    failureMode: "",
    effect: "",
    cause: "",
    severity: 5,
    occurrence: 5,
    detection: 5,
    currentControls: "",
    recommendedActions: "",
  });

  useEffect(() => {
    if (!userLoading && !user) {
      if (typeof window !== "undefined") {
        window.location.href = "/account/signin";
      }
    }
  }, [user, userLoading]);

  useEffect(() => {
    const fetchLines = async () => {
      try {
        const response = await fetch("/api/production-lines");
        if (response.ok) {
          const data = await response.json();
          setLines(data.lines || []);
          if (data.lines && data.lines.length > 0) {
            setSelectedLine(data.lines[0].id);
          }
        }
      } catch (error) {
        console.error("Error fetching lines:", error);
      }
    };
    fetchLines();
  }, []);

  useEffect(() => {
    if (selectedLine) {
      fetchAMDEC();
    }
  }, [selectedLine]);

  const fetchAMDEC = async () => {
    setLoading(true);
    try {
      const response = await fetch(`/api/amdec?lineId=${selectedLine}`);
      if (response.ok) {
        const data = await response.json();
        setAmdecData(data.analysis || []);
      }
    } catch (error) {
      console.error("Error fetching AMDEC:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch("/api/amdec", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          lineId: selectedLine,
          ...formData,
        }),
      });

      if (response.ok) {
        setShowModal(false);
        setFormData({
          processName: "",
          failureMode: "",
          effect: "",
          cause: "",
          severity: 5,
          occurrence: 5,
          detection: 5,
          currentControls: "",
          recommendedActions: "",
        });
        fetchAMDEC();
      }
    } catch (error) {
      console.error("Error creating AMDEC:", error);
    }
  };

  if (userLoading || !user) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-[#F8FAFC]">
        <div className="text-slate-600">Chargement...</div>
      </div>
    );
  }

  const filteredData = amdecData.filter((item) => {
    if (filterStatus === "all") return true;
    return item.status === filterStatus;
  });

  const getNPRColor = (npr) => {
    if (npr >= 200) return "text-red-600 bg-red-50";
    if (npr >= 100) return "text-orange-600 bg-orange-50";
    return "text-yellow-600 bg-yellow-50";
  };

  const getPriorityBadge = (score) => {
    if (score >= 85) return "bg-red-500 text-white";
    if (score >= 70) return "bg-orange-500 text-white";
    return "bg-yellow-500 text-white";
  };

  return (
    <div className="min-h-screen bg-[#F8FAFC] font-inter">
      {/* Top Bar */}
      <header className="fixed top-0 left-0 right-0 z-10 flex items-center justify-between px-4 md:px-6 h-16 bg-white shadow-sm">
        <button
          className="md:hidden p-2 rounded-full hover:bg-gray-100"
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          aria-label="Toggle menu"
        >
          <Menu className="w-5 h-5 stroke-2 text-slate-500" />
        </button>

        <div className="hidden md:flex items-center">
          <span className="text-[20px] font-medium text-slate-700">
            ProcessFlow Smart
          </span>
        </div>

        <div className="flex-1 mx-4 max-w-lg">
          <div className="flex items-center bg-gray-100 rounded-full px-4 py-2">
            <Search className="w-4 h-4 text-slate-400" />
            <select
              value={selectedLine || ""}
              onChange={(e) => setSelectedLine(parseInt(e.target.value))}
              className="flex-1 bg-transparent text-sm pl-2 outline-none cursor-pointer"
            >
              <option value="">Sélectionner une ligne</option>
              {lines.map((line) => (
                <option key={line.id} value={line.id}>
                  {line.name}
                </option>
              ))}
            </select>
            <ChevronDown className="w-4 h-4 text-slate-400" />
          </div>
        </div>

        <div className="flex items-center space-x-4">
          <div className="hidden sm:flex items-center text-sm font-medium text-slate-600">
            <User className="w-5 h-5 mr-2 text-slate-400" />
            {user.name || user.email}
          </div>
          <button className="relative p-2 rounded-full hover:bg-gray-100">
            <Bell className="w-5 h-5 text-slate-400" />
            <span className="absolute top-1 right-1 h-2 w-2 rounded-full bg-orange-500"></span>
          </button>
        </div>
      </header>

      {/* Left Navigation Rail */}
      <aside className="hidden md:flex fixed top-16 left-0 flex-col items-center w-16 py-6 space-y-4 h-[calc(100vh-4rem)] bg-white border-r border-gray-100">
        <a
          href="/"
          className="p-3 rounded-full bg-white shadow ring-1 ring-gray-100 text-slate-400 hover:text-violet-500"
        >
          <LayoutDashboard className="w-5 h-5" />
        </a>
        <button className="p-3 rounded-full shadow ring-1 ring-gray-100 bg-violet-500 text-white">
          <AlertTriangle className="w-5 h-5" />
        </button>
        <a
          href="/actions"
          className="p-3 rounded-full bg-white shadow ring-1 ring-gray-100 text-slate-400 hover:text-violet-500"
        >
          <CheckSquare className="w-5 h-5" />
        </a>
        <a
          href="/reporting"
          className="p-3 rounded-full bg-white shadow ring-1 ring-gray-100 text-slate-400 hover:text-violet-500"
        >
          <FileText className="w-5 h-5" />
        </a>
        <a
          href="/vsm"
          className="p-3 rounded-full bg-white shadow ring-1 ring-gray-100 text-slate-400 hover:text-violet-500"
        >
          <GitBranch className="w-5 h-5" />
        </a>
        <div className="flex-1"></div>
        <a
          href="/settings"
          className="p-3 rounded-full bg-white shadow ring-1 ring-gray-100 text-slate-400 hover:text-violet-500"
        >
          <Settings className="w-5 h-5" />
        </a>
        <a
          href="/account/logout"
          className="p-3 rounded-full bg-white shadow ring-1 ring-gray-100 text-slate-400 hover:text-violet-500"
        >
          <LogOut className="w-5 h-5" />
        </a>
      </aside>

      {/* Main Content */}
      <main className="pt-16 md:pl-16">
        <div className="p-6">
          {/* Header */}
          <div className="flex justify-between items-center mb-6">
            <div>
              <h2 className="text-2xl font-medium text-slate-700">
                AMDEC Intelligente
              </h2>
              <p className="text-sm text-slate-500 mt-1">
                Analyse des modes de défaillance, effets et criticité
              </p>
            </div>
            <button
              onClick={() => setShowModal(true)}
              className="flex items-center space-x-2 bg-violet-500 text-white px-4 py-2 rounded-lg hover:bg-violet-600 transition-colors"
            >
              <Plus className="w-4 h-4" />
              <span>Nouvelle analyse</span>
            </button>
          </div>

          {/* Filters */}
          <div className="flex space-x-3 mb-6">
            <button
              onClick={() => setFilterStatus("all")}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                filterStatus === "all"
                  ? "bg-violet-500 text-white"
                  : "bg-white text-slate-600 hover:bg-gray-50"
              }`}
            >
              Tous ({amdecData.length})
            </button>
            <button
              onClick={() => setFilterStatus("open")}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                filterStatus === "open"
                  ? "bg-violet-500 text-white"
                  : "bg-white text-slate-600 hover:bg-gray-50"
              }`}
            >
              Ouverts
            </button>
            <button
              onClick={() => setFilterStatus("in_progress")}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                filterStatus === "in_progress"
                  ? "bg-violet-500 text-white"
                  : "bg-white text-slate-600 hover:bg-gray-50"
              }`}
            >
              En cours
            </button>
            <button
              onClick={() => setFilterStatus("resolved")}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                filterStatus === "resolved"
                  ? "bg-violet-500 text-white"
                  : "bg-white text-slate-600 hover:bg-gray-50"
              }`}
            >
              Résolus
            </button>
          </div>

          {/* AMDEC Table */}
          <div className="bg-white rounded-[14px] shadow-sm border border-gray-100 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50 border-b border-gray-100">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">
                      Processus
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">
                      Mode de défaillance
                    </th>
                    <th className="px-6 py-3 text-center text-xs font-medium text-slate-500 uppercase tracking-wider">
                      G
                    </th>
                    <th className="px-6 py-3 text-center text-xs font-medium text-slate-500 uppercase tracking-wider">
                      O
                    </th>
                    <th className="px-6 py-3 text-center text-xs font-medium text-slate-500 uppercase tracking-wider">
                      D
                    </th>
                    <th className="px-6 py-3 text-center text-xs font-medium text-slate-500 uppercase tracking-wider">
                      NPR
                    </th>
                    <th className="px-6 py-3 text-center text-xs font-medium text-slate-500 uppercase tracking-wider">
                      Priorité
                    </th>
                    <th className="px-6 py-3 text-center text-xs font-medium text-slate-500 uppercase tracking-wider">
                      Statut
                    </th>
                    <th className="px-6 py-3 text-center text-xs font-medium text-slate-500 uppercase tracking-wider">
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {loading ? (
                    <tr>
                      <td
                        colSpan="9"
                        className="px-6 py-12 text-center text-slate-500"
                      >
                        Chargement...
                      </td>
                    </tr>
                  ) : filteredData.length === 0 ? (
                    <tr>
                      <td
                        colSpan="9"
                        className="px-6 py-12 text-center text-slate-500"
                      >
                        Aucune analyse AMDEC
                      </td>
                    </tr>
                  ) : (
                    filteredData.map((item) => (
                      <tr key={item.id} className="hover:bg-gray-50">
                        <td className="px-6 py-4 text-sm font-medium text-slate-700">
                          {item.process_name}
                        </td>
                        <td className="px-6 py-4 text-sm text-slate-600">
                          {item.failure_mode}
                        </td>
                        <td className="px-6 py-4 text-center text-sm text-slate-700">
                          {item.severity}
                        </td>
                        <td className="px-6 py-4 text-center text-sm text-slate-700">
                          {item.occurrence}
                        </td>
                        <td className="px-6 py-4 text-center text-sm text-slate-700">
                          {item.detection}
                        </td>
                        <td className="px-6 py-4 text-center">
                          <span
                            className={`px-3 py-1 rounded-full text-sm font-medium ${getNPRColor(item.npr)}`}
                          >
                            {item.npr}
                          </span>
                        </td>
                        <td className="px-6 py-4 text-center">
                          <span
                            className={`px-3 py-1 rounded-full text-xs font-medium ${getPriorityBadge(item.priority_score)}`}
                          >
                            {item.priority_score?.toFixed(1)}
                          </span>
                        </td>
                        <td className="px-6 py-4 text-center">
                          <span
                            className={`px-3 py-1 rounded-full text-xs font-medium ${
                              item.status === "open"
                                ? "bg-blue-100 text-blue-700"
                                : item.status === "in_progress"
                                  ? "bg-yellow-100 text-yellow-700"
                                  : "bg-green-100 text-green-700"
                            }`}
                          >
                            {item.status === "open"
                              ? "Ouvert"
                              : item.status === "in_progress"
                                ? "En cours"
                                : "Résolu"}
                          </span>
                        </td>
                        <td className="px-6 py-4 text-center">
                          <button className="text-slate-400 hover:text-violet-500">
                            <Eye className="w-4 h-4" />
                          </button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </main>

      {/* Modal for New AMDEC */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50">
          <div className="bg-white rounded-[14px] p-8 max-w-2xl w-full mx-4 max-h-[90vh] overflow-y-auto">
            <h3 className="text-xl font-medium text-slate-700 mb-6">
              Nouvelle analyse AMDEC
            </h3>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-600 mb-2">
                  Nom du processus
                </label>
                <input
                  type="text"
                  required
                  value={formData.processName}
                  onChange={(e) =>
                    setFormData({ ...formData, processName: e.target.value })
                  }
                  className="w-full rounded-lg border border-gray-200 px-4 py-2 text-sm outline-none focus:border-violet-500 focus:ring-1 focus:ring-violet-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-600 mb-2">
                  Mode de défaillance
                </label>
                <input
                  type="text"
                  required
                  value={formData.failureMode}
                  onChange={(e) =>
                    setFormData({ ...formData, failureMode: e.target.value })
                  }
                  className="w-full rounded-lg border border-gray-200 px-4 py-2 text-sm outline-none focus:border-violet-500 focus:ring-1 focus:ring-violet-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-600 mb-2">
                  Effet
                </label>
                <textarea
                  value={formData.effect}
                  onChange={(e) =>
                    setFormData({ ...formData, effect: e.target.value })
                  }
                  className="w-full rounded-lg border border-gray-200 px-4 py-2 text-sm outline-none focus:border-violet-500 focus:ring-1 focus:ring-violet-500"
                  rows="2"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-600 mb-2">
                  Cause
                </label>
                <textarea
                  value={formData.cause}
                  onChange={(e) =>
                    setFormData({ ...formData, cause: e.target.value })
                  }
                  className="w-full rounded-lg border border-gray-200 px-4 py-2 text-sm outline-none focus:border-violet-500 focus:ring-1 focus:ring-violet-500"
                  rows="2"
                />
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-600 mb-2">
                    Gravité (1-10)
                  </label>
                  <input
                    type="number"
                    min="1"
                    max="10"
                    required
                    value={formData.severity}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        severity: parseInt(e.target.value),
                      })
                    }
                    className="w-full rounded-lg border border-gray-200 px-4 py-2 text-sm outline-none focus:border-violet-500 focus:ring-1 focus:ring-violet-500"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-600 mb-2">
                    Occurrence (1-10)
                  </label>
                  <input
                    type="number"
                    min="1"
                    max="10"
                    required
                    value={formData.occurrence}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        occurrence: parseInt(e.target.value),
                      })
                    }
                    className="w-full rounded-lg border border-gray-200 px-4 py-2 text-sm outline-none focus:border-violet-500 focus:ring-1 focus:ring-violet-500"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-600 mb-2">
                    Détection (1-10)
                  </label>
                  <input
                    type="number"
                    min="1"
                    max="10"
                    required
                    value={formData.detection}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        detection: parseInt(e.target.value),
                      })
                    }
                    className="w-full rounded-lg border border-gray-200 px-4 py-2 text-sm outline-none focus:border-violet-500 focus:ring-1 focus:ring-violet-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-600 mb-2">
                  Contrôles actuels
                </label>
                <textarea
                  value={formData.currentControls}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      currentControls: e.target.value,
                    })
                  }
                  className="w-full rounded-lg border border-gray-200 px-4 py-2 text-sm outline-none focus:border-violet-500 focus:ring-1 focus:ring-violet-500"
                  rows="2"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-600 mb-2">
                  Actions recommandées
                </label>
                <textarea
                  value={formData.recommendedActions}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      recommendedActions: e.target.value,
                    })
                  }
                  className="w-full rounded-lg border border-gray-200 px-4 py-2 text-sm outline-none focus:border-violet-500 focus:ring-1 focus:ring-violet-500"
                  rows="2"
                />
              </div>

              <div className="flex justify-end space-x-3 mt-6">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="px-4 py-2 rounded-lg text-sm font-medium text-slate-600 bg-gray-100 hover:bg-gray-200 transition-colors"
                >
                  Annuler
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-lg text-sm font-medium text-white bg-violet-500 hover:bg-violet-600 transition-colors"
                >
                  Créer l'analyse
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      <style jsx global>{`
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap');
        .font-inter { font-family: 'Inter', sans-serif; }
      `}</style>
    </div>
  );
}
